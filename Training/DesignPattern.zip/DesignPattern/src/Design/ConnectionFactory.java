package Design;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;




public class ConnectionFactory implements ConnectionRequirments {
	// static since it will maintain only one copy accross the application



    private static ConnectionFactory cf = new ConnectionFactory();   



    Connection dbconnection= null; 

    

    // private constructor

    private ConnectionFactory() {   

                    try {

                                    Class.forName(Driver_Class);

                    } catch (ClassNotFoundException e) {

                                    e.printStackTrace();

                    }

    }

    

    

    // private function that generates the connection

    private Connection createConnection() {

                    

                    try {

                                    if (dbconnection==null) {

                                       dbconnection = DriverManager.getConnection(Url, User, Password);

                           System.out.println("\n\nConnected with Oracle .. New Connection Object Returned to Proceed !!");

                                    }else {
                                    	System.out.println("Exesting connection is used");
                                    }

                    } catch (SQLException e) {

                                    System.out.println("ERROR: Unable to Connect to Database.");

                    }

                    return dbconnection;

    }              

    

    // static function outlet for the object.

    public static Connection getConnection() {

                    return cf.createConnection();

    }

    

    

}
	

	

	
	
	
	
	
	
	
	
	
	
