package Design;



public interface ConnectionRequirments {
	public static final String Url="jdbc:oracle:thin:@localhost:1521:XE";
	public static final String User="hr";
	public static final String Password="hr";
	public static final String Driver_Class="oracle.jdbc.OracleDriver";
	
	
	
	
	

}
