package Design;

import java.sql.Connection;
import java.util.ArrayList;

public interface Staffdao {
	
	
	
	 public Connection getDataSource();
	 public void  create(Staff temp); 
	 public  void getStaffDetails(int staffID);
	 public ArrayList  listAllStaffDetails(); 
	 public void delete(int StaffID); 
	 public String  update(int staffID, float SalBonus); 

}
