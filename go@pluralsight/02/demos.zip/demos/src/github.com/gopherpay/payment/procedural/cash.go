package procedural

func PayWithCash(amount float32) bool {
	return true
}
